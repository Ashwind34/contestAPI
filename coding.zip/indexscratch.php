<?php 


echo "$_POST[fname]";
echo "$_POST[lname]";
echo "$_POST[uname]";
echo "$_POST[useremail]";
echo "$_POST[userpass]";
echo "$_POST[team]";




/*echo "$_POST[pass]";

if(!empty($_POST[pass])) {
	
	//echo "hello world";
	
	$pwd = password_hash($_POST[pass],password_default);
	
	echo "$pwd";
	
} /*else {
	echo "error";
}
*/

?>

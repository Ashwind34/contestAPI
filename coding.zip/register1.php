
<?php

require_once('mysqli_connect.php');
	
	//DB query to enter form data

if(!empty($_POST['userpass']) && !empty($_POST['fname']) && !empty($_POST['lname']) && !empty($_POST['useremail']) 
	&& !empty($_POST['uname']) && !empty($_POST['team'])) {

	//Prepared Statement
	
	$insert_player = "INSERT INTO player_roster(first_name, last_name, user_name, email, fav_team, password)
	VALUES ( ?, ? , ? , ? , ? , ? )"; 
	$stmt = $conn->prepare($insert_player);
	
	//Bind Parameters
	
	$stmt->bindparam(ssssss,$_POST['fname'],$_POST['lname'],$_POST['uname'],
	$_POST['useremail'],$_POST['team'],$_POST['userpass']);
		
	//Submit query to database
	
	if($stmt->execute()) {
		echo "User Added Successfully";
	} else {
		echo "Error Adding User, Please Try Again";
	}
}
	
	

mysqli_close($conn);

?>
<!DOCTYPE HTML>
<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<br>
<br>
<br>

<form action="register1.php" method="post">
	First Name <input type="text" name="fname" id="fname"><br><br>
	Last Name  <input type="text" name="lname" id="lname"><br><br>
	Your Email Address <input type="text" name="useremail" id="useremail"><br><br>
	Select User Name <input type="text" name="uname" id="uname"><br><br>
	Favorite NFL Team? <input type="text" name="team" id="team"><br><br>
	Your Password <input type="password" name="userpass" id="userpass"><br><br>
	<input type="submit" name="Register">
<form>

</body>


</html>